package com.sidiq.covid19.config;

public class Constant {

    public static final String BASE_URL = "https://minangtech.com";
    public static final String HOME = "/home";
    public static final String LAST_DATA = "/getCoronaLast";
    public static final String ALL_DATA = "/getDayData";
    public static final String LOCATION = "/sumatera_barat";
}
